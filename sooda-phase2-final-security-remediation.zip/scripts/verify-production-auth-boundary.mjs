import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';

const distRoot = join(process.cwd(), 'dist');
const forbidden = [
  'token_albaraka_owner',
  'token_albaraka_staff',
  'token_nilecrafts_owner',
  'token_platform_admin',
  'DEV_TEST_PRINCIPALS_FIXTURE',
];

if (!existsSync(distRoot)) {
  console.error('PRODUCTION AUTH BOUNDARY FAILED: dist/ does not exist. Run npm run build first.');
  process.exit(1);
}

const files = [];
const walk = (dir) => {
  for (const entry of readdirSync(dir)) {
    const full = join(dir, entry);
    const st = statSync(full);
    if (st.isDirectory()) walk(full);
    else files.push(full);
  }
};
walk(distRoot);

const findings = [];
for (const file of files) {
  let content;
  try {
    content = readFileSync(file, 'utf8');
  } catch {
    continue;
  }
  for (const marker of forbidden) {
    if (content.includes(marker)) findings.push({ file, marker });
  }
}

if (findings.length) {
  console.error('PRODUCTION AUTH BOUNDARY FAILED: development authentication fixtures were found in the production bundle.');
  for (const finding of findings) console.error(`- ${finding.file}: ${finding.marker}`);
  process.exit(1);
}

console.log(`PRODUCTION AUTH BOUNDARY PASSED: scanned ${files.length} production artifact file(s); no development authentication fixtures found.`);
